<?php include('includes/head.php'); ?>
<?php include('includes/header.php'); ?>
<body class="index-page">
  <main class="main">
    <section class="hero section" id="hero">
      <div class="container">
        <h1>Welcome to our store</h1>
        <a href="auth/login.php" class="btn btn-primary">Login</a>
        <a href="auth/register.php" class="btn btn-success">Register</a>
      </div>
    </section>
  </main>
<?php include('includes/footer.php'); ?>
</body>