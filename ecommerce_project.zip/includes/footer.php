<footer class="text-center p-3 bg-light mt-5">
  <p>© 2025 Ecommerce Store</p>
</footer>