<header class="p-3 bg-dark text-white">
  <div class="container">
    <div class="d-flex flex-wrap align-items-center justify-content-between">
      <h3>Shop</h3>
      <nav>
        <a href="index.php" class="btn btn-outline-light">Home</a>
        <a href="dashboard/admin.php" class="btn btn-outline-light">Dashboard</a>
      </nav>
    </div>
  </div>
</header>